<div class="item">
    <?php
    $o = new wpdreamsCustomPostTypesAll("meta_box_post_types", "Display the Ajax Search Pro meta box on these post types",
        $com_options['meta_box_post_types']);
    ?>
</div>