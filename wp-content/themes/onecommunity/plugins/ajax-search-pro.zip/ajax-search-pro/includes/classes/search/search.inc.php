<?php
if (!defined('ABSPATH')) die('-1');

/* Search related classes */
require_once(ASP_CLASSES_PATH . "search/class-asp-query.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-blogs.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-cpt.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-indextable.php");
//require_once(ASP_CLASSES_PATH . "search/search_demo.class.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-comments.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-buddypress.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-terms.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-users.php");
require_once(ASP_CLASSES_PATH . "search/class-asp-search-attachments.php");