<?php
if (!defined('ABSPATH')) die('-1');

require_once(ASP_CLASSES_PATH . "ajax/class-asp-abstract.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-search.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-autocomplete.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-preview.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-priorities.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-deletecache.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-deletekeyword.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-addkeyword.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-indextable.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-maintenance.php");
require_once(ASP_CLASSES_PATH . "ajax/class-asp-license.php");